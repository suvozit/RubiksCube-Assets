//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RubiksCube.rc
//
#define IDD_RUBIKSCUBE_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_CUBE                        1000
#define IDC_SOLUTION_STATIC             1001
#define IDC_EXIT                        1002
#define IDC_SOLVE                       1003
#define IDC_SHUFFLE                     1011
#define IDC_RESET                       1014
#define IDC_MOVELIST                    1015
#define IDC_PREV                        1016
#define IDC_NEXT                        1017
#define IDC_MOVETITLE                   1018
#define IDC_CHANGE_VIEW                 1019
#define IDC_RESET_VIEW                  1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
