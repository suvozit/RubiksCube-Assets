#include <stdio.h>
#include <windows.h>

// Copyright by Ben Jos Walbeehm. Written March-April 2007.
// Licence: This code may be used for non-commercial purposes as long as the author (Ben Jos Walbeehm) is clearly credited.

// Note that we use Dutch notation for the cube faces:
//   Dutch  English
//     R       R
//     B       U
//     V       F
//     L       L
//     O       D
//     A       B

// This is NOT a standalone 4x4x4 cube solver. It just contains some functions that my generic NxNxN cube solver can use to solve a 4x4x4 cube more efficiently.

// RotationCode: (slice{0..3} << 4) + (axis{0..2} << 2) + numtimes{1..3}.

static const DWORD FaceL = 0;
static const DWORD FaceR = 1;
static const DWORD FaceB = 2;
static const DWORD FaceO = 3;
static const DWORD FaceV = 4;
static const DWORD FaceA = 5;

static const DWORD AxisL = 0;
static const DWORD AxisO = 1;
static const DWORD AxisV = 2;

static const BYTE RotateNothing = 0;
static const BYTE RotateCentres = 1;
static const BYTE RotateAll     = 2;

static struct EDGESOLVER
{ DWORD faces[2];
  DWORD codes[2][2];
  char *formulas[2][3];
  DWORD safeedges[2][3];
} *EdgeSolver;

static DWORD SitCount;

static DWORD MaxDim;
static BYTE *CubeFaceColours;
static BYTE  CubeFaceColours4[6*4*4];

static BYTE *ASNptr,ASN[3*256]; // "Axis-Slice-Numtimes".

// For solving the O face centre pieces in the minimal possible amount of turns.
static DWORD OFaceCounts[6] = {1,13,186,2072,8826,10626};
static BYTE  OFaceSolutions[10626];
static WORD  SeqSitLookup[24*24*24*24]; // 663,552 bytes. Returns a value in the range 0..10,625.
static DWORD SeqSitRev[10626]; // Reverse lookup for the above.
static BYTE  Lengths[10626];

/********************************************************/
static __forceinline BYTE GetColour (DWORD face, DWORD x, DWORD y)
{ return CubeFaceColours[(face * MaxDim + x) * MaxDim + y];
} // GetColour

/********************************************************/
static __forceinline BYTE GetColour4 (DWORD face, DWORD x, DWORD y)
{ return CubeFaceColours4[(((face << 2) + x) << 2) + y];
} // GetColour4

/********************************************************/
static __forceinline void SetColour4 (DWORD face, DWORD x, DWORD y, BYTE colour)
{ CubeFaceColours4[(((face << 2) + x) << 2) + y] = colour;
} // SetColour4

/********************************************************/
static void Extract4x4x4Cube ()
{ DWORD face,x,y;

  for (face = 0; face < 6; face++) for (y = 0; y < 4; y++) for (x = 0; x < 4; x++) SetColour4(face,x,y,GetColour(face,x,y));
} // Extract4x4x4Cube

/********************************************************/
// Taken from Ken Silverman's rubix.c. Adapted to my needs and somewhat optimised for the 4x4x4.
#define rotate1(c1,c2,c3,c4) { BYTE c0 = c1; c1 = c2; c2 = c3; c3 = c4; c4 = c0; }
#define rotate2(c1,c2,c3,c4) { BYTE c0 = c1; c1 = c3; c3 = c0; c0 = c2; c2 = c4; c4 = c0; }
#define rotate3(c1,c2,c3,c4) { BYTE c0 = c4; c4 = c3; c3 = c2; c2 = c1; c1 = c0; }

static void Rotate (long axis, long slice, long numtimes, BYTE rotatemode)
{ BYTE *c;

  switch (numtimes & 3)
  { case 1:
      switch (axis)
      { case 0:
          c = &CubeFaceColours4[slice<<2];
          rotate1(c[(2<<4)+2],c[(5<<4)+2],c[(3<<4)+1],c[(4<<4)+1]);
          rotate1(c[(2<<4)+1],c[(5<<4)+1],c[(3<<4)+2],c[(4<<4)+2]);
          if (rotatemode == RotateAll)
          { rotate1(c[(2<<4)+3],c[(5<<4)+3],c[(3<<4)+0],c[(4<<4)+0]);
            rotate1(c[(2<<4)+0],c[(5<<4)+0],c[(3<<4)+3],c[(4<<4)+3]);
          }
          break;
        case 1:
          rotate1(CubeFaceColours4[(((0<<2)+slice)<<2)+2],CubeFaceColours4[(((5<<2)+2)<<2)+slice],CubeFaceColours4[(((1<<2)+slice)<<2)+1],CubeFaceColours4[(((4<<2)+1)<<2)+slice]);
          rotate1(CubeFaceColours4[(((0<<2)+slice)<<2)+1],CubeFaceColours4[(((5<<2)+1)<<2)+slice],CubeFaceColours4[(((1<<2)+slice)<<2)+2],CubeFaceColours4[(((4<<2)+2)<<2)+slice]);
          if (rotatemode == RotateAll)
          { rotate1(CubeFaceColours4[(((0<<2)+slice)<<2)+3],CubeFaceColours4[(((5<<2)+3)<<2)+slice],CubeFaceColours4[(((1<<2)+slice)<<2)+0],CubeFaceColours4[(((4<<2)+0)<<2)+slice]);
            rotate1(CubeFaceColours4[(((0<<2)+slice)<<2)+0],CubeFaceColours4[(((5<<2)+0)<<2)+slice],CubeFaceColours4[(((1<<2)+slice)<<2)+3],CubeFaceColours4[(((4<<2)+3)<<2)+slice]);
          }
          break;
        case 2:
          c = &CubeFaceColours4[slice];
          rotate1(c[(0<<4)+ 8],c[(3<<4)+ 8],c[(1<<4)+ 4],c[(2<<4)+ 4]);
          rotate1(c[(0<<4)+ 4],c[(3<<4)+ 4],c[(1<<4)+ 8],c[(2<<4)+ 8]);
          if (rotatemode == RotateAll)
          { rotate1(c[(0<<4)+12],c[(3<<4)+12],c[(1<<4)+ 0],c[(2<<4)+ 0]);
            rotate1(c[(0<<4)+ 0],c[(3<<4)+ 0],c[(1<<4)+12],c[(2<<4)+12]);
          }
          break;
      }
      if ((DWORD)(slice-1) >= (DWORD)(3-1))
      { c = &CubeFaceColours4[((slice!=0)+(axis<<1))<<4];
        rotate1(c[(1<<2)+2],c[(2<<2)+2],c[(2<<2)+1],c[(1<<2)+1]);
        if (rotatemode == RotateAll)
        { rotate1(c[(1<<2)+3],c[(3<<2)+2],c[(2<<2)+0],c[(0<<2)+1]);
          rotate1(c[(0<<2)+2],c[(2<<2)+3],c[(3<<2)+1],c[(1<<2)+0]);
          rotate1(c[(0<<2)+3],c[(3<<2)+3],c[(3<<2)+0],c[(0<<2)+0]);
        }
      }
      break;
    case 2:
      switch (axis)
      { case 0:
          c = &CubeFaceColours4[slice<<2];
          rotate2(c[(2<<4)+2],c[(5<<4)+2],c[(3<<4)+1],c[(4<<4)+1]);
          rotate2(c[(2<<4)+1],c[(5<<4)+1],c[(3<<4)+2],c[(4<<4)+2]);
          if (rotatemode == RotateAll)
          { rotate2(c[(2<<4)+3],c[(5<<4)+3],c[(3<<4)+0],c[(4<<4)+0]);
            rotate2(c[(2<<4)+0],c[(5<<4)+0],c[(3<<4)+3],c[(4<<4)+3]);
          }
          break;
        case 1:
          rotate2(CubeFaceColours4[(((0<<2)+slice)<<2)+2],CubeFaceColours4[(((5<<2)+2)<<2)+slice],CubeFaceColours4[(((1<<2)+slice)<<2)+1],CubeFaceColours4[(((4<<2)+1)<<2)+slice]);
          rotate2(CubeFaceColours4[(((0<<2)+slice)<<2)+1],CubeFaceColours4[(((5<<2)+1)<<2)+slice],CubeFaceColours4[(((1<<2)+slice)<<2)+2],CubeFaceColours4[(((4<<2)+2)<<2)+slice]);
          if (rotatemode == RotateAll)
          { rotate2(CubeFaceColours4[(((0<<2)+slice)<<2)+3],CubeFaceColours4[(((5<<2)+3)<<2)+slice],CubeFaceColours4[(((1<<2)+slice)<<2)+0],CubeFaceColours4[(((4<<2)+0)<<2)+slice]);
            rotate2(CubeFaceColours4[(((0<<2)+slice)<<2)+0],CubeFaceColours4[(((5<<2)+0)<<2)+slice],CubeFaceColours4[(((1<<2)+slice)<<2)+3],CubeFaceColours4[(((4<<2)+3)<<2)+slice]);
          }
          break;
        case 2:
          c = &CubeFaceColours4[slice];
          rotate2(c[(0<<4)+ 8],c[(3<<4)+ 8],c[(1<<4)+ 4],c[(2<<4)+ 4]);
          rotate2(c[(0<<4)+ 4],c[(3<<4)+ 4],c[(1<<4)+ 8],c[(2<<4)+ 8]);
          if (rotatemode == RotateAll)
          { rotate2(c[(0<<4)+12],c[(3<<4)+12],c[(1<<4)+ 0],c[(2<<4)+ 0]);
            rotate2(c[(0<<4)+ 0],c[(3<<4)+ 0],c[(1<<4)+12],c[(2<<4)+12]);
          }
          break;
      }
      if ((DWORD)(slice-1) >= (DWORD)(3-1))
      { c = &CubeFaceColours4[((slice!=0)+(axis<<1))<<4];
        rotate2(c[(1<<2)+2],c[(2<<2)+2],c[(2<<2)+1],c[(1<<2)+1]);
        if (rotatemode == RotateAll)
        { rotate2(c[(1<<2)+3],c[(3<<2)+2],c[(2<<2)+0],c[(0<<2)+1]);
          rotate2(c[(0<<2)+2],c[(2<<2)+3],c[(3<<2)+1],c[(1<<2)+0]);
          rotate2(c[(0<<2)+3],c[(3<<2)+3],c[(3<<2)+0],c[(0<<2)+0]);
        }
      }
      break;
    case 3:
      switch (axis)
      { case 0:
          c = &CubeFaceColours4[slice<<2];
          rotate3(c[(2<<4)+2],c[(5<<4)+2],c[(3<<4)+1],c[(4<<4)+1]);
          rotate3(c[(2<<4)+1],c[(5<<4)+1],c[(3<<4)+2],c[(4<<4)+2]);
          if (rotatemode == RotateAll)
          { rotate3(c[(2<<4)+3],c[(5<<4)+3],c[(3<<4)+0],c[(4<<4)+0]);
            rotate3(c[(2<<4)+0],c[(5<<4)+0],c[(3<<4)+3],c[(4<<4)+3]);
          }
          break;
        case 1:
          rotate3(CubeFaceColours4[(((0<<2)+slice)<<2)+2],CubeFaceColours4[(((5<<2)+2)<<2)+slice],CubeFaceColours4[(((1<<2)+slice)<<2)+1],CubeFaceColours4[(((4<<2)+1)<<2)+slice]);
          rotate3(CubeFaceColours4[(((0<<2)+slice)<<2)+1],CubeFaceColours4[(((5<<2)+1)<<2)+slice],CubeFaceColours4[(((1<<2)+slice)<<2)+2],CubeFaceColours4[(((4<<2)+2)<<2)+slice]);
          if (rotatemode == RotateAll)
          { rotate3(CubeFaceColours4[(((0<<2)+slice)<<2)+3],CubeFaceColours4[(((5<<2)+3)<<2)+slice],CubeFaceColours4[(((1<<2)+slice)<<2)+0],CubeFaceColours4[(((4<<2)+0)<<2)+slice]);
            rotate3(CubeFaceColours4[(((0<<2)+slice)<<2)+0],CubeFaceColours4[(((5<<2)+0)<<2)+slice],CubeFaceColours4[(((1<<2)+slice)<<2)+3],CubeFaceColours4[(((4<<2)+3)<<2)+slice]);
          }
          break;
        case 2:
          c = &CubeFaceColours4[slice];
          rotate3(c[(0<<4)+ 8],c[(3<<4)+ 8],c[(1<<4)+ 4],c[(2<<4)+ 4]);
          rotate3(c[(0<<4)+ 4],c[(3<<4)+ 4],c[(1<<4)+ 8],c[(2<<4)+ 8]);
          if (rotatemode == RotateAll)
          { rotate3(c[(0<<4)+12],c[(3<<4)+12],c[(1<<4)+ 0],c[(2<<4)+ 0]);
            rotate3(c[(0<<4)+ 0],c[(3<<4)+ 0],c[(1<<4)+12],c[(2<<4)+12]);
          }
          break;
      }
      if ((DWORD)(slice-1) >= (DWORD)(3-1))
      { c = &CubeFaceColours4[((slice!=0)+(axis<<1))<<4];
        rotate3(c[(1<<2)+2],c[(2<<2)+2],c[(2<<2)+1],c[(1<<2)+1]);
        if (rotatemode == RotateAll)
        { rotate3(c[(1<<2)+3],c[(3<<2)+2],c[(2<<2)+0],c[(0<<2)+1]);
          rotate3(c[(0<<2)+2],c[(2<<2)+3],c[(3<<2)+1],c[(1<<2)+0]);
          rotate3(c[(0<<2)+3],c[(3<<2)+3],c[(3<<2)+0],c[(0<<2)+0]);
        }
      }
      break;
  }
} // Rotate

// End of "Taken from Ken Silverman's rubix.c".

/********************************************************/
static void StoreTurn (BYTE axis, BYTE slice, BYTE numtimes, BYTE rotatemode)
{ if (rotatemode != RotateNothing) Rotate(axis,(axis == AxisO) ? 3-slice : slice,numtimes,rotatemode);
  // Before storing the turn, see if we can combine it with the last turn.
  if (ASNptr > ASN)
  { if ((ASNptr[-3] == axis) && (ASNptr[-2] == slice))
    { numtimes = (numtimes + ASNptr[-1]) & 3;
      ASNptr -= 3;
    }
  }
  if (numtimes)
  { ASNptr[0] = axis;
    ASNptr[1] = slice;
    ASNptr[2] = numtimes;
    ASNptr += 3;
  }
} // StoreTurn

/********************************************************/
static DWORD StoreFormula (char *fptr, BYTE rotatemode)
{ BYTE axis,slice,numtimes,*asnptr;

  asnptr = ASNptr;
  while (*fptr)
  { switch (*fptr++)
    { case 'L': axis = (BYTE)AxisL; slice = 0; break;
      case 'l': axis = (BYTE)AxisL; slice = 1; break;
      case 'r': axis = (BYTE)AxisL; slice = 2; break;
      case 'R': axis = (BYTE)AxisL; slice = 3; break;
      case 'O': axis = (BYTE)AxisO; slice = 0; break;
      case 'o': axis = (BYTE)AxisO; slice = 1; break;
      case 'b': axis = (BYTE)AxisO; slice = 2; break;
      case 'B': axis = (BYTE)AxisO; slice = 3; break;
      case 'V': axis = (BYTE)AxisV; slice = 0; break;
      case 'v': axis = (BYTE)AxisV; slice = 1; break;
      case 'a': axis = (BYTE)AxisV; slice = 2; break;
      case 'A': axis = (BYTE)AxisV; slice = 3; break;
    }
    switch (*fptr++)
    { case '0' : numtimes = 0; break;
      case '\0': fptr--; // Fall through. This is so that we can write "R B" instead of "R B ".
      case '1' : // Fall through.
      case ' ' : numtimes = 1; break;
      case '2' : numtimes = 2; break;
      case '3' : // Fall through.
      case '\'': numtimes = 3; break;
    }
    if (numtimes == 0) continue;
    if (slice >= 2) numtimes = 4-numtimes;
    StoreTurn(axis,slice,numtimes,rotatemode);
  }
  return (ASNptr-asnptr)/3;
} // StoreFormula

/********************************************************/
static void DoTurn (DWORD axis, DWORD slice, DWORD numtimes)
{ StoreTurn((BYTE)axis,(BYTE)slice,(BYTE)numtimes,RotateAll);
} // DoTurn

/********************************************************/
static void DoFormula (char *fptr)
{ StoreFormula(fptr,RotateAll);
} // DoFormula

/********************************************************/
static void CheckSituation (DWORD axis, DWORD slice, DWORD numtimes, DWORD len)
{ DWORD i,sitnum;

  for (i = sitnum = 0; i < 6; i++)
  { if (GetColour4(i,1,1) == 1) sitnum = sitnum*24 + i*4;
    if (GetColour4(i,1,2) == 1) sitnum = sitnum*24 + i*4+1;
    if (GetColour4(i,2,1) == 1) sitnum = sitnum*24 + i*4+2;
    if (GetColour4(i,2,2) == 1) sitnum = sitnum*24 + i*4+3;
  }
  if (OFaceSolutions[sitnum=SeqSitLookup[sitnum]] != 0xff) return;
  SitCount++;
  if (axis == AxisO) slice = 3-slice;
  numtimes = -(long)numtimes & 3;
  OFaceSolutions[sitnum] = (BYTE)((slice << 4) + (axis << 2) + numtimes);
  Lengths[sitnum] = (BYTE)len;
} // CheckSituation

/********************************************************/
void BJW4Initialise (int mem_n, char *facelist, BYTE **asnptr, EDGESOLVER *edgesolver)
{ BYTE b;
  DWORD i,j,k,m,len,lastaxis,lastslice,axis,slice,sit,seqsitnum;

  static BOOL initialised = FALSE;

  if (initialised) return;

  MaxDim = (DWORD)mem_n;
  CubeFaceColours = (BYTE *)facelist;
  *asnptr = ASN;
  EdgeSolver = edgesolver;
  // Initialise SeqSitLookup[] and SeqSitRev[].
  for (i = seqsitnum = 0; i < 21; i++) for (j = i+1; j < 22; j++) for (k = j+1; k < 23; k++) for (m = k+1; m < 24; m++)
  { SeqSitRev[seqsitnum] = sit = ((i*24+j)*24+k)*24+m;
    SeqSitLookup[sit] = (WORD)seqsitnum++;
  }
  // Generate all solutions for the centres of the O face. We paint those centres 1 ("white") and the rest of the cube 0 ("black").
  SitCount = 0;
  memset(Lengths,0xff,sizeof(Lengths));
  memset(OFaceSolutions,0xff,sizeof(OFaceSolutions));
  memset(CubeFaceColours4,0,sizeof(CubeFaceColours4));
  CubeFaceColours4[53] = CubeFaceColours4[54] = CubeFaceColours4[57] = CubeFaceColours4[58] = 1;
  // We now have the identity; process it.
  CheckSituation(3,0,3,0);
  // Now repeatedly take solutions that were solved in one turn less and try one turn to see if it results in a situation we do not have yet.
  for (len = 1; len < 6; len++)
  { for (i = 0; i < sizeof(OFaceSolutions); i++)
    { if (Lengths[i] != len-1) continue;
      b = OFaceSolutions[i];
      lastslice = b >> 4;
      lastaxis = (b >> 2) & 3;
      if (lastaxis == AxisO) lastslice = 3-lastslice;
      // Create the situation.
      memset(CubeFaceColours4,0,sizeof(CubeFaceColours4));
      k = SeqSitRev[i];
      for (j = 0; j < 4; j++)
      { sit = k % 24;
        k /= 24;
        SetColour4(sit >> 2,((sit >> 1) & 1) + 1,(sit & 1) + 1,1);
      }
      // Try a bunch of single turns.
      for (axis = 0; axis < 3; axis++) for (slice = 0; slice < 4; slice++) if ((axis != lastaxis) || (slice > lastslice))
      { Rotate(axis,slice,1,RotateCentres);
        CheckSituation(axis,slice,1,len);
        Rotate(axis,slice,1,RotateCentres);
        CheckSituation(axis,slice,2,len);
        Rotate(axis,slice,1,RotateCentres);
        CheckSituation(axis,slice,3,len);
        Rotate(axis,slice,1,RotateCentres);
      }
      if (SitCount == OFaceCounts[len]) break; // Early-out.
    }
  }

  initialised = TRUE;
} // BJW4Initialise

/********************************************************/
DWORD BJW4SolveOFace (BYTE thecolour)
{ DWORD i,x,y,face,code;
  BYTE axis,slice,numtimes;

  ASNptr = ASN;
  for (face = 0; face < 6; face++) for (y = 0; y < 4; y++) for (x = 0; x < 4; x++) SetColour4(face,x,y,GetColour(face,x,y));
  do
  { for (i = code = 0; i < 24; i++) if (GetColour4(i >> 2,((i >> 1) & 1) + 1,(i & 1) + 1) == thecolour) code = code*24 + i;
    code = OFaceSolutions[SeqSitLookup[code]];
    if ((axis = (BYTE)(code >> 2) & 3) == 3) return (ASNptr-ASN)/3;
    slice = (BYTE)(code >> 4);
    numtimes = (BYTE)(code & 3);
    StoreTurn(axis,slice,numtimes,RotateCentres);
  } while (TRUE);

  // This point is never reached.

} // BJW4SolveOFace

/********************************************************/
DWORD BJW4SolveBVFaces (BYTE thecolour)
{ DWORD i,j,numcorrect;
  char ch1,ch2,formula[16];
  BYTE bc,vc,bcolours[4],vcolours[4];
  // 'thecolour' is the correct colour for the V face.
  // Returns the number of turns to solve the BV faces while the actual turns are put into the axis/slice/numtimes arrays.
  // Note that we are going to do edges in stripes after this, so any final l and r slice turns have been omitted.
  // These omitted turns may have to be appended again in case the next stage changes.

  static char *c1formulas[4]   = {"Bil'B'l2V2"   ,"Bir B r2V2"    ,"Bil'B l2V2"    ,"Bir B'r2V2"};     // Note: Final l', r, l', r omitted.
  static char *c2formulas[12]  = {"BiVjr B2"     ,"BiVjr'V2"      ,"Bir B r2V"     ,"Bil'B'l2V'",      // Note: Final r', r, r, l' omitted.
                                  "Vir B2r'B'r B","Vir B'r'B r B2","Vil'B l B'l'B2","Vil'B2l B l'B'",  // Note: Final r', r', l, l omitted.
                                  "Bir'V2r V'r'V","Bil V l'V'l V2","Bir'V'r V r'V2","Bil V2l'V l V'"}; // Note: Final r, l', r, l' omitted.
  static char *c3formulas[4]   = {"Bil'B"        ,"Bir B'"        ,"Bil'B'"        ,"Bir B"     };     // Note: Final l, r', l, r' omitted.
  static char c13numtimes[4*4] = {'2','1','3','0',  '3','2','0','1',  '1','0','2','3',  '0','3','1','2'};

  ASNptr = ASN;
  // V: (0)1,1 (1)2,1   B: (0)1,2 (1)2,2
  //    (2)1,2 (3)2,2      (2)1,1 (3)2,1
  for (i = numcorrect = 0; i < 4; i++)
  { if ((vcolours[i] = GetColour(FaceV,(i & 1) + 1,(i >> 1) + 1)) == thecolour) numcorrect++;
    bcolours[i] = GetColour(FaceB,(i & 1) + 1,2 - (i >> 1));
  }
  formula[0] = '\0';
  switch (numcorrect)
  { case 0:
      strcpy(formula,"r B2r2V2"); // Note: Final r omitted.
      break;
    case 1:
      for (i = 0; vcolours[i] != thecolour; i++) ;
      for (j = 0; bcolours[j] == thecolour; j++) ;
      strcpy(formula,c1formulas[i]);
      formula[1] = c13numtimes[i*4+j];
      break;
    case 2:
      // Create convenient codes vc and bc giving the pattern of the colours that are correct. For instance bc = 0x13 means bcolours[1] and bcolours[3] are correct.
      for (i = 0, vc = 0; i < 4; i++) if (vcolours[i] == thecolour) vc = (vc << 4) + (BYTE)i;
      for (i = 0, bc = 0; i < 4; i++) if (bcolours[i] != thecolour) bc = (bc << 4) + (BYTE)i;
      ch2 = '\0';
      switch (vc)
      { case 0x01:
          switch (bc)
          { case 0x01: i =  1; ch1 = '3'; ch2 = '1'; break;
            case 0x02: i =  1; ch1 = '0'; ch2 = '1'; break;
            case 0x03: i =  6; ch1 = '1'; break;
            case 0x12: i =  7; ch1 = '1'; break;
            case 0x13: i =  1; ch1 = '2'; ch2 = '1'; break;
            case 0x23: i =  1; ch1 = '1'; ch2 = '1'; break;
          }
          break;
        case 0x02:
          switch (bc)
          { case 0x01: i =  0; ch1 = '1'; ch2 = '0'; break;
            case 0x02: i =  0; ch1 = '2'; ch2 = '0'; break;
            case 0x03: i =  4; ch1 = '0'; break;
            case 0x12: i =  5; ch1 = '0'; break;
            case 0x13: i =  0; ch1 = '0'; ch2 = '0'; break;
            case 0x23: i =  0; ch1 = '3'; ch2 = '0'; break;
          }
          break;
        case 0x03:
          switch (bc)
          { case 0x01: i =  9; ch1 = '1'; break;
            case 0x02: i =  8; ch1 = '0'; break;
            case 0x03: i =  3; ch1 = '0'; break;
            case 0x12: i =  3; ch1 = '1'; break;
            case 0x13: i =  9; ch1 = '0'; break;
            case 0x23: i =  8; ch1 = '1'; break;
          }
          break;
        case 0x12:
          switch (bc)
          { case 0x01: i = 11; ch1 = '1'; break;
            case 0x02: i = 10; ch1 = '0'; break;
            case 0x03: i =  2; ch1 = '1'; break;
            case 0x12: i =  2; ch1 = '0'; break;
            case 0x13: i = 11; ch1 = '0'; break;
            case 0x23: i = 10; ch1 = '1'; break;
          }
          break;
        case 0x13:
          switch (bc)
          { case 0x01: i =  1; ch1 = '3'; ch2 = '0'; break;
            case 0x02: i =  1; ch1 = '0'; ch2 = '0'; break;
            case 0x03: i =  6; ch1 = '0'; break;
            case 0x12: i =  7; ch1 = '0'; break;
            case 0x13: i =  1; ch1 = '2'; ch2 = '0'; break;
            case 0x23: i =  1; ch1 = '1'; ch2 = '0'; break;
          }
          break;
        case 0x23:
          switch (bc)
          { case 0x01: i =  0; ch1 = '1'; ch2 = '1'; break;
            case 0x02: i =  0; ch1 = '2'; ch2 = '1'; break;
            case 0x03: i =  4; ch1 = '1'; break;
            case 0x12: i =  5; ch1 = '1'; break;
            case 0x13: i =  0; ch1 = '0'; ch2 = '1'; break;
            case 0x23: i =  0; ch1 = '3'; ch2 = '1'; break;
          }
          break;
      }
      strcpy(formula,c2formulas[i]);
      formula[1] = ch1;
      if (ch2) formula[3] = ch2;
      break;
    case 3:
      for (i = 0; vcolours[i] == thecolour; i++) ;
      for (j = 0; bcolours[j] != thecolour; j++) ;
      strcpy(formula,c3formulas[i]);
      formula[1] = c13numtimes[i*4+j];
      break;
  }
  return StoreFormula(formula,RotateNothing);
} // BJW4SolveBVFaces

/********************************************************/
static void GetVBFacesAndYs (DWORD selector, DWORD *face1, DWORD *y1, DWORD *face2, DWORD *y2)
{ switch (selector)
  { case 0: *face1 = FaceV; *y1 = 0; *face2 = FaceB; *y2 = 0; break;
    case 1: *face1 = FaceB; *y1 = 3; *face2 = FaceA; *y2 = 0; break;
    case 2: *face1 = FaceA; *y1 = 3; *face2 = FaceO; *y2 = 3; break;
    case 3: *face1 = FaceO; *y1 = 0; *face2 = FaceV; *y2 = 3; break;
  }
} // GetVBFacesAndYs

/********************************************************/
static void GetBestVBEdge (BYTE *colour1, BYTE *colour2, DWORD *numlsliceturns)
{ BYTE c1,c2;
  DWORD i,j,y1,y2,face1,face2,slice;

  for (j = 0; j < 4; j++)
  { for (slice = 1; slice < 3; slice++)
    { if ((j > 0) && (slice > 1)) continue;
      GetVBFacesAndYs(j,&face1,&y1,&face2,&y2);
      c1 = GetColour4(face1,slice,y1);
      c2 = GetColour4(face2,slice,y2);
      for (i = 0; i < 4; i++)
      { GetVBFacesAndYs(i,&face1,&y1,&face2,&y2);
        if ((GetColour4(face1,3-slice,y1) == c1) && (GetColour4(face2,3-slice,y2) == c2)) goto choicemade;
      }
    }
  }
choicemade:
  if (j == 4)
  { // No good ones found. Stick to the default.
    c1 = GetColour4(FaceV,1,0);
    c2 = GetColour4(FaceB,1,0);
    j = 0;
  }
  *colour1 = c1;
  *colour2 = c2;
  *numlsliceturns = j;
} // GetBestVBEdge

/********************************************************/
DWORD BJW4SolveEdges1Through8 ()
{ BOOL unstriped;
  BYTE c1,c2,cc1,cc2;
  char *fptr,*minfptr;
  struct EDGESOLVER *es;
  DWORD i,j,x1,x2,y1,y2,idx,edge,face1,face2,slice,minslice,numturns,numcorrect,len,minlen;

  ASNptr = ASN;
  unstriped = FALSE;
  Extract4x4x4Cube();

  for (edge = 0; edge < 8; edge++)
  { GetBestVBEdge(&c1,&c2,&numturns);
    if (numturns) DoTurn(AxisL,1,numturns);
    do
    { for (slice = 1, numcorrect = 0; slice < 3; slice++)
      { for (i = 0; i < 4; i++)
        { switch (i)
          { case 0: face1 = FaceV; y1 = 0; face2 = FaceB; y2 = 0; break;
            case 1: face1 = FaceB; y1 = 3; face2 = FaceA; y2 = 0; break;
            case 2: face1 = FaceA; y1 = 3; face2 = FaceO; y2 = 3; break;
            case 3: face1 = FaceO; y1 = 0; face2 = FaceV; y2 = 3; break;
          }
          if ((GetColour4(face1,slice,y1) == c1) && (GetColour4(face2,slice,y2) == c2))
          { if (i) DoTurn(AxisL,slice,i);
            if (++numcorrect == 2) goto edgedone;
            break;
          }
        }
      }
      // The remainder has to come from flipped edgelets in the horizontal edges and from the R and L faces. Determine the cheapest way of getting one or more.
      minlen = (DWORD)(-1);
      // Try to find flipped edgelets.
      for (slice = 1; slice < 3; slice++)
      { for (i = 0; i < 4; i++)
        { switch (i)
          { case 0: face1 = FaceV; y1 = 0; face2 = FaceB; y2 = 0; break;
            case 1: face1 = FaceB; y1 = 3; face2 = FaceA; y2 = 0; break;
            case 2: face1 = FaceA; y1 = 3; face2 = FaceO; y2 = 3; break;
            case 3: face1 = FaceO; y1 = 0; face2 = FaceV; y2 = 3; break;
          }
          if ((GetColour4(face1,slice,y1) == c2) && (GetColour4(face2,slice,y2) == c1))
          { len = 4;
            if (i == 0) len = 5;
            if (len < minlen)
            { minlen = len;
              minslice = slice;
              minfptr = (char *)i;
            }
          }
        }
      }
      // Try to find edgelets in the R and L faces.
      for (i = 0, es = EdgeSolver; i < 8; i++, es++)
      { for (slice = 1; slice < 3; slice++)
        { x1 = slice; if (es->codes[0][0] != 1) x1 = es->codes[0][0];
          y1 = slice; if (es->codes[0][1] != 1) y1 = es->codes[0][1];
          x2 = slice; if (es->codes[1][0] != 1) x2 = es->codes[1][0];
          y2 = slice; if (es->codes[1][1] != 1) y2 = es->codes[1][1];
          cc1 = GetColour4(es->faces[0],x1,y1);
          cc2 = GetColour4(es->faces[1],x2,y2);
          if ((cc1 == c2) && (cc2 == c1)) idx = 0; else if ((cc1 == c1) && (cc2 == c2)) idx = 1; else continue;
          for (j = 0; (j < 3) && ((fptr = es->formulas[idx][j])) && (es->safeedges[idx][j] < edge); j++) ;
          if ((j < 3) && (fptr))
          { if ((len = ((strlen(fptr) + 1) >> 1)) < minlen)
            { minlen = len;
              minfptr = fptr;
            }
          }
        }
      }
      // Use the cheapest way to get more available for the "1 slice turn" code above.
      if ((DWORD)minfptr <= 3)
      { // Flipped edgelet.
        i = (DWORD)minfptr;
        if (i == 0)
        { DoTurn(AxisL,minslice,3);
          // If there are more flipped ones in VB, then get those out to be flipped as well.
          for (j = minslice+1; j < 3; j++) if ((GetColour4(FaceV,j,0) == c2) && (GetColour4(FaceB,j,0) == c1)) DoTurn(AxisL,j,3);
        }
        if (i == 3) DoFormula("O2A2O2A2"); else DoFormula("A2O2A2O2");
      } else
      { // From the R or L face.
        DoFormula(minfptr);
      }
    } while (TRUE);
edgedone:
    // Turn it into a safe place. The first 3 are turned into the L face, the next 3 into the R face, the 7th is put in the L face, the 8th in the R face.
    if (edge < 6)
    { if (edge < 3)
      { slice = 0;
        numturns = 3;
      } else
      { slice = 3;
        numturns = 1;
      }
      DoTurn(AxisO,3,numturns);
      DoTurn(AxisL,slice,3);
      if (GetColour4(FaceV,1,1) != GetColour4(FaceV,2,1)) DoTurn(AxisO,3,4-numturns);
    } else
    { // Move it to LB without disturbing the sliced B V O A faces. Whatever is at LB will move to RB, which means we do not have to distinguish between the 7th and 8th edge.
      if (GetColour4(FaceV,1,1) != GetColour4(FaceV,2,1))
      { DoFormula("R'V'B'V B");
        if (edge == 6) DoFormula("R");
      } else
      { if (edge == 6)
        { DoFormula("B"); } else
        { // Edge 7. Put everything in the B face immediately.
          DoFormula("V2O L2");
          unstriped = TRUE;
        }
      }
    }
  }
  // Restore the slices.
  c1 = GetColour4(FaceV,1,1);
  while (GetColour4(FaceV,2,1) != c1) DoTurn(AxisL,2,1);
  if (!unstriped) DoFormula("B V2A2"); // To put the remaining ones in the B face. We use the B face as our "main" face from now on.
  return (ASNptr-ASN)/3;
} // BJW4SolveEdges1Through8

/********************************************************/
