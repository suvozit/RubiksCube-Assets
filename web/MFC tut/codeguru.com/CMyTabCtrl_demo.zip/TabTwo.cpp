// TabTwo.cpp : implementation file
//

#include "stdafx.h"
#include "MyTabExample.h"
#include "TabTwo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabTwo dialog


CTabTwo::CTabTwo(CWnd* pParent /*=NULL*/)
	: CDialog(CTabTwo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTabTwo)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTabTwo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTabTwo)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTabTwo, CDialog)
	//{{AFX_MSG_MAP(CTabTwo)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabTwo message handlers
