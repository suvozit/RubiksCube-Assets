#if !defined(AFX_TABTWO_H__7E062B52_3B6E_44C4_B58E_AAD73592C8E3__INCLUDED_)
#define AFX_TABTWO_H__7E062B52_3B6E_44C4_B58E_AAD73592C8E3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TabTwo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTabTwo dialog

class CTabTwo : public CDialog
{
// Construction
public:
	CTabTwo(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTabTwo)
	enum { IDD = IDD_TAB_TWO };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTabTwo)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTabTwo)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABTWO_H__7E062B52_3B6E_44C4_B58E_AAD73592C8E3__INCLUDED_)
