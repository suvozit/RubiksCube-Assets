// TabThree.cpp : implementation file
//

#include "stdafx.h"
#include "MyTabExample.h"
#include "TabThree.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabThree dialog


CTabThree::CTabThree(CWnd* pParent /*=NULL*/)
	: CDialog(CTabThree::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTabThree)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTabThree::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTabThree)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTabThree, CDialog)
	//{{AFX_MSG_MAP(CTabThree)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabThree message handlers
