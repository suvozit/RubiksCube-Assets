// TabDlg.h : header file
//

#pragma once
#include "afxcmn.h"
#include "tabpageone.h"
#include "tabpagetwo.h"
#include "ibtabctrl.h"

// CTabDlg dialog
class CTabDlg : public CDialog
{
// Construction
public:
	CTabDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_TAB_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
private:
	CTabPageOne *p1;
	CTabPageTwo *p2;
	int m_bInit;
public:
	CibTabCtrl m_ctrlTAB;
	afx_msg void OnMove(int x, int y);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
};
