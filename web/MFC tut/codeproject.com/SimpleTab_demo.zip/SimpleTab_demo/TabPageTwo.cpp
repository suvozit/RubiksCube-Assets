// TabPageTwo.cpp : implementation file
//

#include "stdafx.h"
#include "Tab.h"
#include "TabPageTwo.h"


// CTabPageTwo dialog

IMPLEMENT_DYNAMIC(CTabPageTwo, CDialog)
CTabPageTwo::CTabPageTwo(CWnd* pParent /*=NULL*/)
	: CDialog(CTabPageTwo::IDD, pParent)
{
}

CTabPageTwo::~CTabPageTwo()
{
}

void CTabPageTwo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CTabPageTwo, CDialog)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
END_MESSAGE_MAP()


// CTabPageTwo message handlers

void CTabPageTwo::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here

}
