// TabDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Tab.h"
#include "TabDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CTabDlg dialog



CTabDlg::CTabDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTabDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_bInit = false;
	p1=NULL;
	p2=NULL;
}

void CTabDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TAB, m_ctrlTAB);
}

BEGIN_MESSAGE_MAP(CTabDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_MOVE()
	ON_WM_SHOWWINDOW()
END_MESSAGE_MAP()


// CTabDlg message handlers

BOOL CTabDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	p1 = new CTabPageOne();
	p1->Create(IDD_DIALOG_PAGE1,m_ctrlTAB.GetWindow(IDD_DIALOG_PAGE1));
	p2 = new CTabPageTwo();
	p2->Create(IDD_DIALOG_PAGE2,m_ctrlTAB.GetWindow(IDD_DIALOG_PAGE2));
	m_ctrlTAB.AddTabPane("Tab Intro",p1);
	m_ctrlTAB.AddTabPane("My Tab Pages",p2);

	
	
	//m_ctrlTAB.Ad
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTabDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTabDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CTabDlg::OnMove(int x, int y)
{
	m_ctrlTAB.OnMove(x,y); 
}

void CTabDlg::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CDialog::OnShowWindow(bShow, nStatus);
	m_ctrlTAB.SetDefaultPane(1);
}
