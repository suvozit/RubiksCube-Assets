//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Tab.rc
//
#define IDR_MANIFEST                    1
#define IDD_TAB_DIALOG                  102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_PAGE1                130
#define IDD_DIALOG_PAGE2                131
#define IDB_BITMAP_INTRO                132
#define IDC_TAB                         1000
#define IDC_CUSTOM1                     1002
#define IDC_LIST1                       1003
#define IDC_EDIT1                       1004
#define IDC_COMBO1                      1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
