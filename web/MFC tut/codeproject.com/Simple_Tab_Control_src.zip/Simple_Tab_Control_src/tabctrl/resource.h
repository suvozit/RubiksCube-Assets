//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by tabctrl.rc
//
#define IDD_TABCTRL_DIALOG              102
#define IDD_PP_ONE                      103
#define IDD_PP_TWO                      104
#define IDD_PP_THREE                    107
#define IDR_MAINFRAME                   128
#define IDB_BMP_PAGE1                   130
#define IDB_BMP_PAGE2                   131
#define IDC_TABV                        1001
#define IDC_EDIT_NAME                   1002
#define IDC_EDIT2                       1003
#define IDC_EDIT_PASSWORD               1003
#define IDC_BUTTON1                     1004
#define IDC_BUTTON_MSG                  1005
#define IDC_BUTTON_RP2                  1006
#define IDC_BUTTON3                     1007
#define IDC_BUTTON_RP3                  1007
#define IDC_BUTTON_RP1                  1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
