#pragma once

//chars representing colors
#define YELLOW 1
#define BLUE   2
#define RED    3
#define ORANGE 4
#define GREEN  5
#define WHITE  6
